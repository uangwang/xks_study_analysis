create definer = root@localhost view view_test as
select `learn_test`.`tb_user`.`id`         AS `id`,
       `learn_test`.`tb_user`.`name`       AS `name`,
       `learn_test`.`tb_user`.`phone`      AS `phone`,
       `learn_test`.`tb_user`.`email`      AS `email`,
       `learn_test`.`tb_user`.`profession` AS `profession`,
       `learn_test`.`tb_user`.`age`        AS `age`,
       `learn_test`.`tb_user`.`gender`     AS `gender`,
       `learn_test`.`tb_user`.`status`     AS `status`,
       `learn_test`.`tb_user`.`createtime` AS `createtime`
from `learn_test`.`tb_user`
where (`learn_test`.`tb_user`.`gender` = 1);

-- comment on column view_test.id not supported: 主键

-- comment on column view_test.name not supported: 用户名

-- comment on column view_test.phone not supported: 手机号

-- comment on column view_test.email not supported: 邮箱

-- comment on column view_test.profession not supported: 专业

-- comment on column view_test.age not supported: 年龄

-- comment on column view_test.gender not supported: 性别 , 1: 男, 2: 女

-- comment on column view_test.status not supported: 状态

-- comment on column view_test.createtime not supported: 创建时间

