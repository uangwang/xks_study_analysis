create
    definer = root@localhost procedure get_student_count()
BEGIN
    DECLARE count INT;
    SELECT COUNT(*) INTO count FROM student;
    SELECT count;
END;

