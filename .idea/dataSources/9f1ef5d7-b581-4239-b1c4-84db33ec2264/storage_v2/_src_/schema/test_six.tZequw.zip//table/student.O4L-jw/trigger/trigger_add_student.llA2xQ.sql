create definer = root@localhost trigger trigger_add_student
    after insert
    on student
    for each row
    INSERT INTO student1 (Sno, Sname, Ssex, Sage, Sdept)
VALUES (NEW.Sno, NEW.Sname, NEW.Ssex,NEW.Sage,New.Sdept);

