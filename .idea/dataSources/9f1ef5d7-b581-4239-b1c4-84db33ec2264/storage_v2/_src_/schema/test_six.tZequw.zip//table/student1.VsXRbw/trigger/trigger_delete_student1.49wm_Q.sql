create definer = root@localhost trigger trigger_delete_student1
    before delete
    on student1
    for each row
begin
        delete from sc where sno=OLD.sno;
    end;

