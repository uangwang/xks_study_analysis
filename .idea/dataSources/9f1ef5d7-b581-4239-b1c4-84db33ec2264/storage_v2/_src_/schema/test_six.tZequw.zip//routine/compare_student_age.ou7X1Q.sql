create
    definer = root@localhost procedure compare_student_age(IN s1 int, IN s2 int)
BEGIN
    DECLARE flag INT;
    SELECT IF((SELECT Sage FROM student WHERE sno = s1) > (SELECT Sage FROM student WHERE sno = s2), 0, 1) INTO flag;
    SELECT flag;
END;

