create definer = root@localhost trigger trigger_add_course
    after insert
    on course
    for each row
    INSERT INTO course1 (cno, cname, Cpno,Ccredit)
VALUES (NEW.cno, NEW.cname, NEW.Cpno,NEW.Ccredit);

