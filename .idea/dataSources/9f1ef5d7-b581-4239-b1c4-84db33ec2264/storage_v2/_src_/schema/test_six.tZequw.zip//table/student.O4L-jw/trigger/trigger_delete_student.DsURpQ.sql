create definer = root@localhost trigger trigger_delete_student
    before delete
    on student
    for each row
BEGIN
        DELETE FROM sc WHERE sno = OLD.sno;
    END;

